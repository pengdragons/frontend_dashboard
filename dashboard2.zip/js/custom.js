$(".select-image").change(function(){
  var file = $(this)[0].files[0];
  var imageChange = $(this).parent().parent().parent().children('.image-logo');
  console.log(file.type);
  var patterImage = new RegExp("image/*");
  if(!patterImage.test(file.type)) {
          alert("Please choose image");
  } else {
          var fileReader = new FileReader();
          fileReader.readAsDataURL(file);
          fileReader.onload = function(e) {
            imageChange.attr("src",e.target.result);
                  // $(this).parent().parent().parent().children('.image-logo').attr("src",e.target.result);
          }
  }
});



$(document).ready(function(){
  $(".label-title-form-interface").click(function(){
    if($(this).parent().children('.content-div-form-interface').is(':hidden')){
      $(this).parent().children('.content-div-form-interface').slideDown();
      $(this).children('span').removeClass('fa fa-angle-down');
      $(this).children('span').addClass('fa fa-angle-up');
    }else{
      $(this).parent().children('.content-div-form-interface').slideUp();
      $(this).children('span').removeClass('fa fa-angle-up');
      $(this).children('span').addClass('fa fa-angle-down');
    }
  });
});

