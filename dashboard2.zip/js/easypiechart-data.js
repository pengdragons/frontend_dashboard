$(function() {
    $('#easypiechart-1').easyPieChart({
        scaleColor: false,
        barColor: '#7376df'
    });
});

$(function() {
    $('#easypiechart-2').easyPieChart({
        scaleColor: false,
        barColor: '#7376df'
    });
});

$(function() {
    $('#easypiechart-3').easyPieChart({
        scaleColor: false,
        barColor: '#7376df'
    });
});

$(function() {
   $('#easypiechart-4').easyPieChart({
       scaleColor: false,
       barColor: '#7376df'
   });
});
